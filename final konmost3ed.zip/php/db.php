<?php
$con = mysqli_connect('localhost','id16816548_konmost3ed','M@tkdemk@nm@st3ed','id16816548_motkdem');

if(mysqli_connect_errno()){
	echo 'فشل الاتصال بقاعدة البيانات';
}
?>